# L Aerospace Shared Libraries / KSP Division :: Change Log

* 2024-1222: 0.0.1.2 (LisiasT) for KSP >= 1.2
	+ Being slightly less obtuse and realising that not every `ModuleAnimateGeneric` is a Light... 🤦
* 2023-0705: 0.0.1.1 (LisiasT) for KSP >= 1.2
	+ A series of unfortunate mishaps fixed.
		- Can't imagine how in hell I let all this crap pass trough…
	+ Updates the `Aviation Lights` support to cope with the new API introduced on AL 4.2.1.0.
		- Needs `Aviation Lights` 4.2.1.0 or newer, by obvious reasons.
* 2023-0213: 0.0.1.0 (LisiasT) for KSP >= 1.2
	+ Initial release. **#HURRAY!!**
