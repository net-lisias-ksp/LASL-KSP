# L Aerospace Shared Libraries / KSP Division :: Change Log

* 2023-0213: 0.0.1.0 (LisiasT) for KSP >= 1.2
	+ Initial release. **#HURRAY!!**
